Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/framebuf_simpletest.py
    :caption: examples/framebuf_simpletest.py
    :linenos:
