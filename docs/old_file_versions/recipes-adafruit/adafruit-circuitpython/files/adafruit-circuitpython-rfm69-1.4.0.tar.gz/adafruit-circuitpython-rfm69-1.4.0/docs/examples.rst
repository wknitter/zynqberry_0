Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/rfm69_simpletest.py
    :caption: examples/rfm69_simpletest.py
    :linenos:
