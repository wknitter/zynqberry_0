"""Boards definition from Zynqberry"""
